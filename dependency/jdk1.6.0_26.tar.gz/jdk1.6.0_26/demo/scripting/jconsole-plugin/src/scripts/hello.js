/*
 * This is sample JavaScript file that can be loaded into script console.
 * This file prints "hello, world".
 */

echo("hello, world");
